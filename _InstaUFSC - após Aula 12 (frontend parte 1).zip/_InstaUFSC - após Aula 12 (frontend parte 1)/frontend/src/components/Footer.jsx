import "./Footer.css";

const Footer = () => {
  return (
    <footer id="footer">
      <p>InstaUFSC &copy; 2023</p>
    </footer>
  );
};

export default Footer;
